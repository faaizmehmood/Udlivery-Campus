export const Colors={
    statusbarcolor:'green',
    internetbackcolor:'green',
    onlinebackcolor:'green',
    internettextcolor:'#FFFFFF',
    onlinetextcolor:'#FFFFFF',
    mediabackground:'#FFFFFF',
    mediatextcolor:'black',
    cancletextcolor:'black',
    buttoncolor:'red',
    whiteColor:'#FFFFFF',
    greyColor:'gray',
    Otpresedcolor:'green',
    otpcountcolor:'red',
    otpverifycolor:'#1985ff',
}
export const Font={
    popping_bold:'bold'
}