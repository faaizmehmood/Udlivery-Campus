
export const localimag={
    crossb:require('./icons/cancelb.png'),
    crossw:require('./icons/cancelw.png'),
    arrowl:require('./icons/backl.png'),
    arrowld:require('./icons/backlb.png'),
    arrowr:require('./icons/backr.png'),
    arrowlw:require('./icons/backlw.png'),
    maplocation:require('./icons/location.png')
}